<?php

use App\Http\Controllers\Admin\StudentAttendanceExportController;
use App\Http\Controllers\ProfileController;
use App\Models\Announcement;
use App\Models\Staff;
use App\Models\Student;
use App\Livewire\Admin\ViewStudentAttendance;
use App\Livewire\Auth\FacultyStaffLogin;
use App\Livewire\Auth\ForgotPassword;
use App\Livewire\Auth\StudentLogin;
use App\Livewire\Auth\StudentSelfEnrollment;
use App\Livewire\Student\MyGrade;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;

Route::get('/', function () {
    return view('welcome', [
        'studentCount' => Schema::hasTable('students') ? Student::count() : 0,
        'staffCount' => Schema::hasTable('staff') ? Staff::count() : 0,
        'announcements' => Schema::hasTable('announcements')
            ? Announcement::query()
                ->where('is_active', true)
                ->latest()
                ->take(3)
                ->get()
            : collect(),
    ]);
})->name('home');
Route::get('/about', function () {
    return view('pages.about');
})->name('about');

Route::get('/how-to-enroll', function () {
    return view('pages.how-to-enroll');
})->name('how-to-enroll');

Route::get('/announcements', function () {
    return view('pages.announcements');
})->name('announcements');

Route::get('/student-login', StudentLogin::class)->name('student-login');
Route::get('/student-enrollment', StudentSelfEnrollment::class)
    ->middleware('guest')
    ->name('student.self-enrollment');
Route::get('/faculty-staff-login', FacultyStaffLogin::class)->name('faculty-staff-login');
Route::get('/dashboard', function () {
    switch (auth()->user()->user_type) {
        case 'admin':
            return redirect()->route('admin.staffs');
        case 'teacher':
            return redirect()->route('teacher.dashboard');

        case 'student':
            return redirect()->route('student.index');

        default:
            // code...
            break;
    }
})->middleware(['auth', 'verified'])->name('dashboard');

Route::prefix('administrator')->middleware(['auth', 'verified', 'role:admin'])->group(function () {
    Route::get('/dashboard', function () {
        return redirect()->route('admin.staffs');
    }
    )->name('admin.dashboard');
    Route::get('/staffs', function () {
        return view('admin.staffs');
    }
    )->name('admin.staffs');
    Route::get('/grade-level', function () {
        return view('admin.grade-level');
    }
    )->name('admin.grade-level');
    Route::get('/grade-level/subjects/{id}', function () {
        return view('admin.grade-level-subjects');
    }
    )->name('admin.grade-level-subjects');
    Route::get('/section/{id}', function () {
        return view('admin.section');
    }
    )->name('admin.section');
    Route::get('/students', function () {
        return view('admin.students');
    }
    )->name('admin.students');

    Route::get('/students/create', function () {
        return view('admin.students-create');
    }
    )->name('admin.students-create');

    Route::get('/students/{id}', function () {
        return view('admin.students-record');
    }
    )->name('admin.students-record');

    Route::get('/students/{id}/grades', function ($id) {
        return view('admin.view-student-grades', ['studentId' => $id]);
    })->name('admin.student-grades');

    Route::get('/students/{student}/attendance', ViewStudentAttendance::class)
        ->name('admin.student-attendance');
    Route::get('/students/{student}/attendance/export/{format}', StudentAttendanceExportController::class)
        ->name('admin.student-attendance.export');

    Route::get('/view-student-grades', function () {
        return view('admin.view-student-grades');
    })->name('admin.view-student-grades');

    Route::get('/request', function () {
        return view('admin.request');
    }
    )->name('admin.request');

    Route::get('/calendar', function () {
        return view('admin.calendar');
    }
    )->name('admin.calendar');

    Route::get('/notfication', function () {
        return view('admin.notification');
    }
    )->name('admin.notification');

    Route::get('/record', function () {
        return view('admin.record');
    }
    )->name('admin.record');

    Route::get('/academic-year', function () {
        return view('admin.academic-year');
    })->name('admin.academic-year');

    Route::get('/announcements', function () {
        return view('admin.announcements');
    })->name('admin.announcements');
});

Route::prefix('teacher')->middleware(['auth', 'verified', 'role:teacher'])->group(function () {
    Route::get('/dashboard', function () {
        return view('teacher.dashboard');
    })->name('teacher.dashboard');

    Route::get('/attendance-and-grading', function () {
        return view('teacher.attendance-and-grading');
    })->name('teacher.attendance-and-grading');

    Route::get('/attendance/records', function () {
        return view('teacher.view-records');
    })->name('teacher.view-records');

    Route::get('/students/create', function () {
        return view('teacher.students-create');
    })->name('teacher.students-create');

    Route::redirect('/attendance', '/teacher/attendance-and-grading');
    Route::redirect('/grading', '/teacher/attendance-and-grading');

    Route::get('/calendar', function () {
        return view('teacher.calendar');
    })->name('teacher.calendar');
});

Route::prefix('student')->middleware(['auth', 'verified', 'role:student', 'student.password.changed'])->group(function () {
    Route::get('/dashboard', function () {
        return view('student.index');
    }
    )->name('student.index');

    Route::get('/request', function () {
        return view('student.request');
    }
    )->name('student.request');
    Route::get('/calendar', function () {
        return view('student.calendar');
    }
    )->name('student.calendar');
    Route::get('/grade', MyGrade::class)->name('student.grade');
});

Route::get('/forgot-password', ForgotPassword::class)
    ->middleware('guest')
    ->name('password.request');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
