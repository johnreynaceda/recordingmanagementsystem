<?php

namespace App\Livewire\Student;

use App\Models\Student;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;

class Profile extends Component
{
    use WithFileUploads;

    public $student;

    public $section;

    public $gradeLevel;

    public $isEditing = false;

    // Editable fields
    public $firstname;

    public $middlename;

    public $lastname;

    public $contact_number;

    public $parent_name;

    public $parent_contact;

    public $birthdate;

    public $address;

    public $new_image;

    public function mount()
    {
        $this->loadStudentData();
    }

    public function loadStudentData()
    {
        /** @var Student|null $student */
        $student = Student::with(['studentRecords.section', 'studentRecords.gradeLevel'])
            ->where('user_id', auth()->id())
            ->first();

        $this->student = $student;

        $latestRecord = $student ? $student->studentRecords->last() : null;

        if ($latestRecord) {
            $this->section = $latestRecord->section->name ?? 'N/A';
            $this->gradeLevel = $latestRecord->gradeLevel->name ?? 'N/A';
        } else {
            $this->section = 'N/A';
            $this->gradeLevel = 'N/A';
        }
    }

    public function edit()
    {
        /** @var Student|null $student */
        $student = $this->student;
        if (! $student) {
            return;
        }

        $this->isEditing = true;
        $this->firstname = $student->firstname;
        $this->middlename = $student->middlename;
        $this->lastname = $student->lastname;
        $this->contact_number = $student->contact_number;
        $this->parent_name = $student->parent_name;
        $this->parent_contact = $student->parent_contact;
        $this->birthdate = $student->birthdate;
        $this->address = $student->address;
        $this->new_image = null;
    }

    public function cancelEdit()
    {
        $this->isEditing = false;
        $this->new_image = null;
    }

    public function save()
    {
        /** @var Student|null $student */
        $student = $this->student;
        if (! $student) {
            return;
        }

        $this->validate([
            'firstname' => 'required|string|max:255',
            'middlename' => 'nullable|string|max:255',
            'lastname' => 'required|string|max:255',
            'contact_number' => ['nullable', 'string', 'regex:/^\+63\d{10}$/'],
            'parent_name' => 'nullable|string|max:255',
            'parent_contact' => ['nullable', 'string', 'regex:/^\+63\d{10}$/'],
            'birthdate' => 'required|date',
            'address' => 'required|string|max:500',
            'new_image' => 'nullable|image|max:2048', // 2MB Max
        ], [
            'contact_number.regex' => 'The contact number must use the +63 international format followed by 10 digits (for example, +639171234567).',
            'parent_contact.regex' => 'The parent contact number must use the +63 international format followed by 10 digits (for example, +639171234567).',
        ]);

        if ($this->new_image) {
            if ($student->image_path) {
                Storage::disk('public')->delete($student->image_path);
            }
            /** @var UploadedFile $image */
            $image = $this->new_image;
            $imagePath = $image->store('students/profiles', 'public');
            $student->image_path = $imagePath;
            $student->save();
        }

        $student->update([
            'firstname' => $this->firstname,
            'middlename' => $this->middlename,
            'lastname' => $this->lastname,
            'contact_number' => $this->contact_number,
            'parent_name' => $this->parent_name,
            'parent_contact' => $this->parent_contact,
            'birthdate' => $this->birthdate,
            'address' => $this->address,
        ]);

        $this->loadStudentData();
        $this->isEditing = false;
        $this->new_image = null;

        sweetalert()->success('Profile updated successfully!');
        session()->flash('success', 'Profile updated successfully.');
    }

    public function render()
    {
        return view('livewire.student.profile', [
            'student' => $this->student,
            'section' => $this->section,
            'gradeLevel' => $this->gradeLevel,
        ]);
    }
}
