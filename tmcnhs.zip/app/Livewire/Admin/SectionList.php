<?php

namespace App\Livewire\Admin;

use App\Models\GradeLevel;
use App\Models\Section;
use App\Models\Staff;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Support\Enums\IconPosition;
use Filament\Tables\Actions\Action;
use Filament\Tables\Actions\CreateAction;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Livewire\Component;

class SectionList extends Component implements HasForms, HasTable
{
    use InteractsWithTable;
    use InteractsWithForms;

    public $grade_level_id;

    public function mount()
    {
        $this->grade_level_id = request('id');
    }

    private function teacherOptions(): array
    {
        return Staff::with('user')->get()->mapWithKeys(function ($staff) {
            return [$staff->id => $staff->firstname . ' ' . $staff->lastname];
        })->toArray();
    }

    public function table(Table $table): Table
    {
        return $table
            ->query(
                Section::query()
                    ->where('grade_level_id', $this->grade_level_id)
            )
            ->headerActions([
                CreateAction::make('section')
                    ->label('New Section')
                    ->icon('heroicon-o-plus')
                    ->iconPosition(IconPosition::After)
                    ->mutateFormDataUsing(function (array $data): array {
                        $data['grade_level_id'] = $this->grade_level_id;

                        return $data;
                    })
                    ->form([
                        TextInput::make('name')->required(),
                    ])
                    ->modalWidth('xl')
                    ->modalHeading('Create Section'),
            ])
            ->columns([
                TextColumn::make('name')->label('NAME'),
                TextColumn::make('staff')
                    ->label('TEACHER')
                    ->formatStateUsing(fn($record) => $record->staff ? $record->staff->firstname . ' ' . $record->staff->lastname : 'Not Assigned'),
            ])
            ->actions([
                Action::make('teacher')
                    ->label('Assign Teacher')
                    ->icon('heroicon-o-user-plus')
                    ->button()
                    ->color('success')
                    ->action(function ($record, $data) {
                        $record->update([
                            'staff_id' => $data['staff'],
                        ]);
                    })
                    ->form([
                        Select::make('staff')
                            ->label('Teacher')
                            ->options($this->teacherOptions())
                            ->searchable()
                            ->required(),
                    ])
                    ->modalWidth('xl')
                    ->visible(fn($record) => $record->staff_id == null || $record->staff == null),
                EditAction::make('edit')
                    ->color('success')
                    ->action(function ($record, $data) {
                        $record->update([
                            'name' => $data['name'],
                            'staff_id' => $data['staff_id'] ?? null,
                        ]);
                    })
                    ->form([
                        TextInput::make('name')->required(),
                        Select::make('staff_id')
                            ->label('Teacher')
                            ->options($this->teacherOptions())
                            ->searchable()
                            ->placeholder('Select a teacher')
                            ->nullable(),
                    ])
                    ->modalWidth('xl')
                    ->modalHeading('Edit Section'),
                DeleteAction::make('delete'),
            ])
            ->bulkActions([
                // ...
            ])
            ->emptyStateHeading('No Section yet')
            ->emptyStateDescription('Once you add the first section, it will appear here.');
    }

    public function render()
    {
        return view('livewire.admin.section-list', [
            'name' => GradeLevel::where('id', $this->grade_level_id)->first()->name,
        ]);
    }
}
