<div>
  {{$this->table}}
</div>
