<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('term_grades', function (Blueprint $table) {
            $table->string('final_rating')->nullable()->after('fourth_grading');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('term_grades', function (Blueprint $table) {
            $table->dropColumn('final_rating');
        });
    }
};
